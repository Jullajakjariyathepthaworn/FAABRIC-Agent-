#!/bin/bash
# Starts the FAABRIC Agent on a Mac. Keep this window open while you use the FAABRIC web page.
cd "$(dirname "$0")" || exit 1
case "$(uname -m)" in
  arm64) BIN=FAABRIC-Agent-arm64 ;;
  *) BIN=FAABRIC-Agent-x64 ;;
esac
chmod +x "$BIN" 2>/dev/null
xattr -dr com.apple.quarantine "$BIN" 2>/dev/null
# macOS only runs a program that carries a signature; an ad-hoc one made on this Mac is enough
codesign --force --sign - "$BIN" >/dev/null 2>&1
echo "FAABRIC Agent for Mac"
echo "Keep this window open, then press Upload on the FAABRIC web page."
echo
exec "./$BIN"
