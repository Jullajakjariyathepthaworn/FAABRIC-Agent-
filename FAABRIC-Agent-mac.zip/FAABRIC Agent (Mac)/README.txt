FAABRIC Agent for Mac

1. Unzip this folder.
2. Right-click "Start-FAABRIC-Agent.command" and choose Open (the first time only; macOS asks once because the file came from the internet).
3. Keep the window that opens running while you use the FAABRIC web page, then press Upload.

Works on Apple Silicon and Intel Macs. It needs the internet the first time you upload to an ESP32 (it downloads the board tools).

Ubuntu/Windows users: use the other download on the Upload window.
